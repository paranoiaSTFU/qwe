﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UP.DB
{
    public partial class Tour
    {
        public string NameView { get { return $"Назавание тура: {Name}"; } }
        public string PriceView { get { return $"Цена тура: {Price}"; } }
        public string DateStartView { get { return $"Дата начала тура: {DateStart}"; } }
        public string DateEndView { get { return $"Дата окончания тура: {DateEnd}"; } }
        public string FoodView { get { return $""; } }
        public string CountryView { get { return $"Страна тура: {CountryList.Name}"; } }
        public string UsersView { get { return $""; } }
        public string VauncerHotelView { get { return $""; } }
        public string VauncherTransferView { get { return $""; } }
        public string TicketView { get { return $""; } }



        public string btnRoleAdmin
        {
            get
            {
                if (App.UserContext.Role1.ID == 1)
                {
                    return "Visible";
                }
                else
                    return "Hidden";

            }
        }
        public string BtnRoleUser
        {
            get
            {
                if (App.UserContext.Role1.ID == 3)
                {
                    return "Visible";
                }
                else
                    return "Hidden";

            }
        }
        public string BtnRoleManager
        {
            get
            {
                if (App.UserContext.Role1.ID == 2)
                {
                    return "Visible";
                }
                else
                    return "Hidden";

            }
        }

    }
}
