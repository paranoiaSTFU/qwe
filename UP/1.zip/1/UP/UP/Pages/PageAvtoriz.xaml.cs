﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace UP.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAvtoriz.xaml
    /// </summary>
    public partial class PageAvtoriz : Page
    {
        public PageAvtoriz()
        {
            InitializeComponent();
        }

        private void BtnEnter_Click(object sender, RoutedEventArgs e)
        {
            if (TbLogin.Text.Length == 0 || TbPassword.Password.Length == 0)
            { MessageBox.Show("Заполните поля", "Error", MessageBoxButton.OK, MessageBoxImage.Error); }
            else
            {
                var a = App.Context.Users;
                if (a.Where(p => p.Login == TbLogin.Text && p.Password == TbPassword.Password).Count() == 1)
                {
                    App.UserContext = a.FirstOrDefault(p => p.Login == TbLogin.Text && p.Password == TbPassword.Password);
                    NavigationService.Navigate(new Pages.PageTour());
                }
                else
                    MessageBox.Show("Пользователь не найден", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }
    }
}
