﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace UP.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageTour.xaml
    /// </summary>
    public partial class PageTour : Page
    {
        public PageTour()
        {

            InitializeComponent();
            if (App.UserContext.Role == 1)
            {
                  NewTour.Visibility = Visibility.Visible;
            }
            else
            {
              NewTour.Visibility = Visibility.Hidden;
            }
            var Type = App.Context.TypeTours.Select(p => p.Name).ToList();
            Type.Insert(0, "Все");
            CBTypeTour.ItemsSource = Type.ToList();
            var Country = App.Context.CountryLists.Select(p => p.Name).ToList();
            Country.Insert(0, "Все");
            CBCountryTour.ItemsSource = Country.ToList();
            CBCountryTour.SelectedIndex = 0;
            CBTypeTour.SelectedIndex = 0;
            CBCountryTour.FontSize = 8;
            CBTypeTour.FontSize = 8;
            TbCostMax.Text = "99999";
            TbCostMin.Text = "0";
            Update();
        }
        public void Update()
        {
            try
            {
                var a = App.Context.Tours.ToList();
                int CostMax = 1000;
                int CostMin = 0;
                if (Int32.TryParse(TbCostMax.Text, out CostMax) && Int32.TryParse(TbCostMin.Text, out CostMin))
                {
                    if (CostMax < CostMin)
                    {
                        MessageBox.Show("Не верное значение цены", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                    else
                        a = a.Where(p => p.Price >= CostMin && p.Price <= CostMax).ToList();//сортировка по цене
                }
                else
                {
                    MessageBox.Show("Не соответствующий тип данных", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                if (TbPoisk.Text != null)
                    a = a.Where(p => p.Name.ToLower().Contains(TbPoisk.Text.ToLower())).ToList();//поиск по названию
                if (CBCountryTour.SelectedItem.ToString() != "Все")
                    a = a.Where(p => p.CountryList.Name.ToLower().Contains(CBCountryTour.SelectedItem.ToString().ToLower())).ToList();//фильтр по стране
                if (CBTypeTour.SelectedIndex != 0)
                    a = a.Where(p => p.TypeTours.Select(j => j.ID).Contains(CBTypeTour.SelectedIndex)).ToList();//фильтр по типу тура


                LVTour.ItemsSource = a;
            }
            catch (Exception e)
            {
               MessageBox.Show(e.Message);
            }
        }

        private void TbCostMin_TextChanged(object sender, TextChangedEventArgs e)
        {
            Update();
        }

        private void TbCostMax_TextChanged(object sender, TextChangedEventArgs e)
        {
            Update();
        }

        private void TbPoisk_TextChanged(object sender, TextChangedEventArgs e)
        {
            Update();
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Pages.PageNewTour());
        }

        private void Zakaz_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Pages.PageZakazTour());
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            Update();
        }

        private void CBTypeTour_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Update();
        }

        private void CBCountryTour_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Update();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            Update();
        }

        private void View_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Pages.PageViewTour());
        }

        private void NewTour_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Pages.PageNewTour());
        }
    }
}
