﻿using System;
using System.Windows;

namespace UP
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            MainFrame.Navigate(new Pages.PageAvtoriz());
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            if (MainFrame.CanGoBack)
                MainFrame.GoBack();
            if (BtnBack.Content.ToString() == "Выйти")
            {
                this.Close();
                        }    
        }

        private void Window_ContentRendered(object sender, EventArgs e)
        {
            if (MainFrame.CanGoBack)
            {
                ResizeMode = ResizeMode.CanResize;
                BtnBack.Content = "Назад";
            }
            else
            {
                ResizeMode = ResizeMode.NoResize;
                Width = 800;
                Height = 450;
                BtnBack.Content = "Выйти";
            }
        }
    }
}
